# Free Email Templates by Colorlib.

Free HTML email templates for Mailchimp and other emails services

Huge selection of the best free email templates you will ever find. All templates are responsive and will work with all popular emails such as Gmail, Outlook and ohers. You can use these templates with MailChimp or any other email delivery service. 

# Here is a preview of one of the templates

![Free email Templates](https://colorlib.com/wp/wp-content/uploads/sites/2/email-templates.jpg)

For more email templates like this one [please see this list](https://colorlib.com/wp/responsive-html-email-templates/). 

# License

MIT license, see LICENSE-MIT for details.
